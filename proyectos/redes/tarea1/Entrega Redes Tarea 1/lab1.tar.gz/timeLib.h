
/*
 * timeLib.h
 *
 *  Created on: Sep 5, 2012
 *      Author: dell
 */

#ifndef TIMELIB_H_
#define TIMELIB_H_

#include "logger.h"

int stringToTime(const char *date);
int getToday();


#endif /* TIMELIB_H_ */
